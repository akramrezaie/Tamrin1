﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbl_Result = new System.Windows.Forms.Label();
            this.txt_value = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.picStart = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picGameOver = new System.Windows.Forms.PictureBox();
            this.picWin = new System.Windows.Forms.PictureBox();
            this.picError = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picStart)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGameOver)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picError)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Result
            // 
            this.lbl_Result.Location = new System.Drawing.Point(40, 91);
            this.lbl_Result.Name = "lbl_Result";
            this.lbl_Result.Size = new System.Drawing.Size(174, 24);
            this.lbl_Result.TabIndex = 0;
            // 
            // txt_value
            // 
            this.txt_value.Location = new System.Drawing.Point(40, 30);
            this.txt_value.Name = "txt_value";
            this.txt_value.Size = new System.Drawing.Size(100, 21);
            this.txt_value.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(40, 57);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(220, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 77);
            this.label3.TabIndex = 4;
            this.label3.Text = "0";
            // 
            // picStart
            // 
            this.picStart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picStart.BackgroundImage")));
            this.picStart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picStart.Location = new System.Drawing.Point(40, 123);
            this.picStart.Name = "picStart";
            this.picStart.Size = new System.Drawing.Size(267, 232);
            this.picStart.TabIndex = 5;
            this.picStart.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.Controls.Add(this.picGameOver);
            this.panel1.Controls.Add(this.picWin);
            this.panel1.Controls.Add(this.lbl_Result);
            this.panel1.Controls.Add(this.picError);
            this.panel1.Controls.Add(this.picStart);
            this.panel1.Controls.Add(this.txt_value);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(24, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(334, 383);
            this.panel1.TabIndex = 6;
            // 
            // picGameOver
            // 
            this.picGameOver.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picGameOver.BackgroundImage")));
            this.picGameOver.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picGameOver.Location = new System.Drawing.Point(40, 123);
            this.picGameOver.Name = "picGameOver";
            this.picGameOver.Size = new System.Drawing.Size(267, 232);
            this.picGameOver.TabIndex = 9;
            this.picGameOver.TabStop = false;
            // 
            // picWin
            // 
            this.picWin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picWin.BackgroundImage")));
            this.picWin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picWin.Location = new System.Drawing.Point(40, 123);
            this.picWin.Name = "picWin";
            this.picWin.Size = new System.Drawing.Size(267, 232);
            this.picWin.TabIndex = 8;
            this.picWin.TabStop = false;
            // 
            // picError
            // 
            this.picError.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picError.BackgroundImage")));
            this.picError.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picError.ErrorImage = null;
            this.picError.Location = new System.Drawing.Point(40, 123);
            this.picError.Name = "picError";
            this.picError.Size = new System.Drawing.Size(267, 232);
            this.picError.TabIndex = 7;
            this.picError.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(386, 440);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Guess";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picStart)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGameOver)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picError)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_Result;
        private System.Windows.Forms.TextBox txt_value;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox picStart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox picError;
        private System.Windows.Forms.PictureBox picWin;
        private System.Windows.Forms.PictureBox picGameOver;
    }
}

