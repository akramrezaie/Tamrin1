﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int count = 0;
        Boolean GameStart = true;
        int ValueGuess = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            count++;

            Random rnd = new Random();
            if (GameStart)
            {
                ValueGuess = rnd.Next(0, 100);
                GameStart = false;
            }

            int valueCheck = int.Parse(txt_value.Text);
            if (ValueGuess==valueCheck)
            {
                win();
                int r = Convert.ToInt32(MessageBox.Show("You Win!!! Do You Want to Try Again?", "Try Again", MessageBoxButtons.YesNo, MessageBoxIcon.Question));

                if (r == 6)
                    start();
            }
            else 
            {
                error();

                if (ValueGuess < valueCheck)
                    lbl_Result.Text = "Enter Lower Number";
                else
                    lbl_Result.Text = "Enter Higher Number";

                if (count>7)
                {
                    gameover();
                    int r =Convert.ToInt32(MessageBox.Show("You Game Over. Do You Want to Try Again?", "Try Again", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
                   if (r==6)
                        start();
                }
            }
            label3.Text = count.ToString();
            txt_value.Text = "";
        }

        private void  start()
        {
            GameStart = true;
            count = 1;
            picStart.Visible = true;
            picWin.Visible = false;
            picError.Visible = false;
            picGameOver.Visible = false;
            lbl_Result.Text = null;
        }

        private void win()
        {
            picStart.Visible = false;
            picWin.Visible = true;
            picError.Visible = false;
            picGameOver.Visible = false;
        }

        private void error()
        {
            picStart.Visible = false;
            picWin.Visible = false;
            picError.Visible = true;
            picGameOver.Visible = false;
        }

        private void gameover()
        {
            picStart.Visible = false;
            picWin.Visible = false;
            picError.Visible = false;
            picGameOver.Visible = true;
        }
    }
}
